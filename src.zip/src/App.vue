<template>
  <router-view />
</template>

<style>
/* 全局重置，確保沒有奇怪的邊距 */
body {
  margin: 0;
  padding: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  background-color: #f9fafb;
}
</style>
