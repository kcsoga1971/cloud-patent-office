<!-- src/components/workflow/ServiceTips.vue -->
<template>
  <div class="service-tips">
    <h3>💡 服務提示</h3>
    <ul>
      <li>初稿完成後，請仔細檢查內容</li>
      <li>修訂稿可以多次修改</li>
      <li>送件前請確認所有資料正確</li>
    </ul>
  </div>
</template>

<style scoped>
.service-tips {
  background: #f0f9ff;
  border: 1px solid #0ea5e9;
  border-radius: 8px;
  padding: 16px;
  margin: 16px 0;
}

.service-tips h3 {
  margin: 0 0 12px 0;
  color: #0284c7;
}

.service-tips ul {
  margin: 0;
  padding-left: 20px;
}

.service-tips li {
  margin: 8px 0;
  color: #334155;
}
</style>
