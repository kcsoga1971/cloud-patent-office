<template>
  <div class="p-6">
    <h1 class="text-2xl font-bold">專案列表 (Projects)</h1>
    <p>這裡是專案清單。</p>
  </div>
</template>