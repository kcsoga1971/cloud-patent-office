<!-- src/views/services/DesignAroundWorkflow.vue -->
<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { supabase } from '../../supabase'
import { useUserStore } from '../../stores/user'
import { formatDate } from '../../utils/formatters'
import ServiceTips from '../../components/ServiceTips.vue' // ✅ 確保引入小撇步
import { usePatentDocx } from '../../composables/usePatentDocx'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

// ========== 視圖狀態管理 (View State) ==========
// 'dashboard': 列表與統計 | 'wizard': 新增流程 | 'report': 詳情結果
const currentView = ref('dashboard') 
const isLoading = ref(false)
const allJobs = ref([])
const activeFilter = ref('all')

// ========== Wizard (新增流程) 狀態 ==========
const wizardStep = ref(1) // 1:模式選擇, 2:資料準備, 3:構想輸入
const analysisMode = ref('search') // 'search' | 'upload'
const searchKeyword = ref('')
const searchResults = ref([])
const selectedPatents = ref([]) // 使用者選定的目標專利 (包含檔案或搜尋結果)
const myIdea = ref('')
const constraints = ref('') // 限制條件
const wizardLoading = ref(false)
const COST = 800

// ========== Report (報告) 狀態 ==========
const currentJobId = ref(null)
const resultData = ref(null)
const jobStatus = ref('')
const pollTimer = ref(null)

// ====================================================
// 🟢 Level 1: 儀表板邏輯 (Dashboard)
// ====================================================

// 載入案件列表
const loadJobs = async () => {
  if (!userStore.user) return
  isLoading.value = true
  try {
    const { data, error } = await supabase
      .from('saas_jobs')
      .select('*')
      .eq('user_id', userStore.user.id)
      .eq('job_type', 'patent_design_around')
      .order('updated_at', { ascending: false })
    
    if (error) throw error
    allJobs.value = data || []
  } catch (err) {
    console.error('載入失敗', err)
  } finally {
    isLoading.value = false
  }
}

// 統計數據
const stats = computed(() => {
  const jobs = allJobs.value
  return {
    total: jobs.length,
    processing: jobs.filter(j => ['pending', 'analyzing', 'processing'].includes(j.status)).length,
    completed: jobs.filter(j => j.status === 'completed').length
  }
})

// 列表篩選
const filteredJobs = computed(() => {
  let jobs = allJobs.value
  if (activeFilter.value === 'processing') {
    jobs = jobs.filter(j => ['pending', 'analyzing', 'processing'].includes(j.status))
  } else if (activeFilter.value === 'completed') {
    jobs = jobs.filter(j => j.status === 'completed')
  }
  return jobs
})

// UI Helper: 狀態標籤
const getStatusInfo = (job) => {
  if (job.status === 'completed') return { label: '✅ 分析完成', class: 'status-success' }
  if (job.status === 'failed') return { label: '❌ 失敗', class: 'status-error' }
  return { label: '⏳ AI 運算中', class: 'status-processing' }
}

const getJobTitle = (job) => {
  // 優先顯示目標，其次顯示構想摘要
  if (job.input_data?.target_count > 1) return `矩陣分析：針對 ${job.input_data.target_count} 篇專利`
  return job.input_data?.my_idea?.substring(0, 25) + '...' || '未命名專案'
}

// 切換到詳情頁
const goToDetail = (jobId) => {
  currentJobId.value = jobId
  currentView.value = 'report'
  loadJobDetail(jobId)
}

// 切換到新增精靈
const startNewAnalysis = () => {
  // 重置 Wizard 狀態
  wizardStep.value = 1
  analysisMode.value = 'search'
  searchKeyword.value = ''
  searchResults.value = []
  selectedPatents.value = []
  myIdea.value = ''
  constraints.value = ''
  currentView.value = 'wizard'
}

// ====================================================
// 🟡 Level 2: 互動精靈邏輯 (Wizard)
// ====================================================

// Step 2a: 處理檢索 (Human-in-the-Loop)
const handleSearch = async () => {
  if (!searchKeyword.value) return alert('請輸入關鍵字')
  wizardLoading.value = true
  searchResults.value = []
  
  try {
    // 呼叫簡易檢索 API (只查不存 DB)
    const response = await fetch(import.meta.env.VITE_N8N_WEBHOOK_SEARCH_URL, { // 需確保此環境變數存在
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ keyword: searchKeyword.value })
    })
    const data = await response.json()
    // 假設回傳結構 { items: [...] }
    if (data.items) {
      searchResults.value = data.items.map(item => ({ ...item, selected: false }))
    }
  } catch (e) {
    alert('搜尋暫時無法使用，請稍後再試')
  } finally {
    wizardLoading.value = false
  }
}

// 勾選/取消搜尋結果
const toggleSearchResult = (item) => {
  item.selected = !item.selected
  if (item.selected) {
    if (selectedPatents.value.length >= 5) {
      item.selected = false
      return alert('為確保矩陣分析品質，建議最多選擇 5 篇專利。')
    }
    selectedPatents.value.push({
      type: 'search_result',
      title: item.title,
      number: item.patent_number,
      abstract: item.abstract,
      link: item.link
    })
  } else {
    const idx = selectedPatents.value.findIndex(p => p.number === item.patent_number)
    if (idx !== -1) selectedPatents.value.splice(idx, 1)
  }
}

// Step 2b: 處理上傳
const handleFiles = (e) => {
  const files = Array.from(e.target.files)
  if (files.length + selectedPatents.value.length > 5) return alert('最多 5 份文件')
  
  files.forEach(f => {
    selectedPatents.value.push({
      type: 'file',
      title: f.name,
      number: 'Uploaded PDF',
      file: f
    })
  })
}

const removeSelected = (index) => {
  const item = selectedPatents.value[index]
  // 同步取消搜尋列表的勾選狀態
  if (item.type === 'search_result') {
    const origin = searchResults.value.find(r => r.patent_number === item.number)
    if (origin) origin.selected = false
  }
  selectedPatents.value.splice(index, 1)
}

// Step 3: 執行分析 (Execute Job)
const executeAnalysis = async () => {
  if (!userStore.user) return alert('請先登入')
  if (!myIdea.value) return alert('請輸入您的技術構想')
  
  if (!confirm(`即將針對 ${selectedPatents.value.length} 篇目標進行矩陣分析，需扣除 ${COST} 點。確定嗎？`)) return
  
  wizardLoading.value = true
  let transactionId = null

  try {
    // 1. 扣點
    const { data: reserve } = await supabase.rpc('reserve_credits', {
      p_user_id: userStore.user.id, p_credits: COST,
      p_action_type: 'DESIGN_AROUND', p_description: '矩陣迴避分析',
      p_model_name: 'Claude-3.5', p_job_id: null, p_project_id: null
    })
    transactionId = reserve.transaction_id

    // 2. 建立 Job
    const { data: job } = await supabase.from('saas_jobs').insert({
      user_id: userStore.user.id,
      job_type: 'patent_design_around',
      status: 'pending',
      payment_status: 'reserved',
      transaction_id: transactionId,
      input_data: {
        my_idea: myIdea.value,
        constraints: constraints.value,
        target_count: selectedPatents.value.length,
        // 僅儲存 Meta Data 供紀錄
        targets_meta: selectedPatents.value.map(p => ({ title: p.title, number: p.number }))
      }
    }).select().single()
    
    currentJobId.value = job.id

    // 3. 上傳檔案 (若有)
    const filePaths = []
    const uploadFiles = selectedPatents.value.filter(p => p.type === 'file')
    
    for (let i = 0; i < uploadFiles.length; i++) {
      const file = uploadFiles[i].file
      const path = `design-around/${job.id}/${file.name}`
      await supabase.storage.from('patent-documents').upload(path, file)
      filePaths.push(path)
    }

    // 4. 更新 Job 並呼叫 n8n
    // 我們同時傳送 "檔案路徑" 和 "搜尋到的文字資料" 給 n8n
    // n8n 會優先讀檔，若無檔則讀取 search_targets_data
    await supabase.from('saas_jobs').update({
      input_data: { 
        ...job.input_data, 
        target_file_paths: filePaths,
        search_targets_data: selectedPatents.value.filter(p => p.type === 'search_result')
      }
    }).eq('id', job.id)

    // Call Webhook
    fetch(import.meta.env.VITE_N8N_WEBHOOK_DESIGN_AROUND_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ job_id: job.id, transaction_id: transactionId })
    })

    // 轉跳到報告頁
    currentView.value = 'report'
    startPolling()

  } catch (e) {
    console.error(e)
    alert('啟動失敗: ' + e.message)
    wizardLoading.value = false
  }
}

// ====================================================
// 🔵 Level 3: 報告詳情邏輯 (Report)
// ====================================================

const loadJobDetail = async (id) => {
  const { data } = await supabase.from('saas_jobs').select('*').eq('id', id).single()
  if (data) {
    jobStatus.value = data.status
    if (data.result_data) {
      resultData.value = typeof data.result_data === 'string' ? JSON.parse(data.result_data) : data.result_data
    }
    // 如果還在跑，繼續輪詢
    if (['pending', 'analyzing', 'processing'].includes(data.status)) {
      startPolling()
    }
  }
}

const startPolling = () => {
  if (pollTimer.value) clearInterval(pollTimer.value)
  pollTimer.value = setInterval(async () => {
    if (!currentJobId.value) return
    const { data } = await supabase.from('saas_jobs').select('*').eq('id', currentJobId.value).single()
    
    jobStatus.value = data.status
    if (data.status === 'completed') {
      resultData.value = typeof data.result_data === 'string' ? JSON.parse(data.result_data) : data.result_data
      userStore.fetchUser() // 更新餘額
      clearInterval(pollTimer.value)
      wizardLoading.value = false
      loadJobs() // 刷新列表
    }
  }, 3000)
}

onUnmounted(() => { if (pollTimer.value) clearInterval(pollTimer.value) })
onMounted(() => loadJobs())

// 下載報告
const { generateDesignAroundReport, isGenerating } = usePatentDocx()
const downloadReport = async () => {
  if (!resultData.value) return
  await generateDesignAroundReport({
    fileName: `迴避設計報告`,
    targetNumber: 'Matrix Analysis',
    myIdea: '', 
    resultData: resultData.value
  })
}

// 採用策略
const adoptStrategy = (strategy) => {
  if (!confirm('確定採用此策略？將引導您進入專利撰寫流程。')) return
  router.push({
    path: '/services/drafting-workflow',
    query: {
      from: 'design-around',
      title: strategy.title,
      solution: strategy.description
    }
  })
}

const getRiskClass = (level) => {
  if (level?.includes('High')) return 'risk-high'
  if (level?.includes('Medium')) return 'risk-medium'
  return 'risk-low'
}
</script>

<template>
  <div class="workflow-container">
    
    <div v-if="currentView === 'dashboard'">
      <div class="header">
        <div class="header-left">
          <h1>🛡️ 專利迴避設計管理</h1>
          <p class="subtitle">管理您的迴避設計專案，查看侵權風險矩陣與技術突圍策略</p>
        </div>
        <div class="header-actions">
          <button @click="loadJobs" class="btn-secondary">🔄 重新整理</button>
          <button @click="startNewAnalysis" class="btn-primary">➕ 新增迴避設計</button>
        </div>
      </div>

      <div class="dashboard-grid">
        <div class="stat-card" :class="{ active: activeFilter === 'all' }" @click="activeFilter = 'all'">
          <span class="stat-value">{{ stats.total }}</span>
          <span class="stat-label">全部專案</span>
        </div>
        <div class="stat-card orange" :class="{ active: activeFilter === 'processing' }" @click="activeFilter = 'processing'">
          <span class="stat-value">{{ stats.processing }}</span>
          <span class="stat-label">⏳ 分析中</span>
        </div>
        <div class="stat-card green" :class="{ active: activeFilter === 'completed' }" @click="activeFilter = 'completed'">
          <span class="stat-value">{{ stats.completed }}</span>
          <span class="stat-label">✅ 已完成</span>
        </div>
      </div>

      <div v-if="isLoading" class="loading"><div class="spinner"></div>載入中...</div>
      
      <div v-else-if="filteredJobs.length > 0" class="job-list">
        <div v-for="job in filteredJobs" :key="job.id" class="job-card" @click="goToDetail(job.id)">
          <div class="card-header">
            <span class="uuid">#{{ job.id.slice(0,8) }}</span>
            <span class="status-badge" :class="getStatusInfo(job).class">{{ getStatusInfo(job).label }}</span>
          </div>
          <h3 class="job-title">{{ getJobTitle(job) }}</h3>
          <div class="job-meta">
            <span>📅 {{ formatDate(job.created_at) }}</span>
            <span class="target-badge" v-if="job.input_data?.target_count">
              🎯 目標數: {{ job.input_data.target_count }}
            </span>
            <span v-if="job.result_data?.infringement_risk_assessment" class="risk-text">
              ⚖️ {{ job.result_data.infringement_risk_assessment.risk_level }} Risk
            </span>
          </div>
        </div>
      </div>

      <div v-else class="empty-state">
        <p>📭 目前沒有迴避設計專案</p>
        <button @click="startNewAnalysis" class="btn-primary">開始第一個分析</button>
      </div>

      <div class="tips-area">
        <ServiceTips type="design_around" />
      </div>
    </div>

    <div v-if="currentView === 'wizard'" class="wizard-container">
      <div class="page-header">
        <button @click="currentView = 'dashboard'" class="btn-back">← 取消並返回</button>
        <h1>🧙 互動式迴避導航</h1>
      </div>

      <div class="stepper">
        <div class="step" :class="{ active: wizardStep >= 1 }">1. 選擇模式</div>
        <div class="line"></div>
        <div class="step" :class="{ active: wizardStep >= 2 }">2. 鎖定目標</div>
        <div class="line"></div>
        <div class="step" :class="{ active: wizardStep >= 3 }">3. 構想與限制</div>
      </div>

      <div v-if="wizardStep === 1" class="step-content text-center">
        <h2>您手邊是否有競爭對手的專利資料？</h2>
        <div class="mode-cards">
          <div class="card choice-card" @click="analysisMode='upload'; wizardStep=2">
            <div class="icon">📂</div>
            <h3>有，我有 PDF 檔案</h3>
            <p>直接上傳目標專利文件進行精準分析。</p>
          </div>
          <div class="card choice-card" @click="analysisMode='search'; wizardStep=2">
            <div class="icon">🔍</div>
            <h3>沒有，幫我找找看</h3>
            <p>輸入關鍵字，AI 幫您快篩出潛在威脅並讓您勾選。</p>
          </div>
        </div>
      </div>

      <div v-if="wizardStep === 2 && analysisMode === 'upload'" class="step-content">
        <div class="form-card">
          <h3>📂 上傳目標專利</h3>
          <p class="hint">請上傳您想要迴避的專利文件 (PDF)，AI 將建立矩陣進行比對。</p>
          
          <div class="file-drop-zone">
            <input type="file" multiple accept=".pdf" @change="handleFiles" />
            <p>點擊或拖曳檔案至此</p>
          </div>
          
          <ul class="selected-list" v-if="selectedPatents.length > 0">
            <li v-for="(p, idx) in selectedPatents" :key="idx">
              📄 {{ p.title }} <button @click="removeSelected(idx)" class="btn-xs">移除</button>
            </li>
          </ul>
          
          <div class="wizard-actions">
            <button @click="wizardStep = 1" class="btn-text">上一步</button>
            <button @click="wizardStep = 3" class="btn-next" :disabled="selectedPatents.length === 0">下一步 →</button>
          </div>
        </div>
      </div>

      <div v-if="wizardStep === 2 && analysisMode === 'search'" class="step-content">
        <div class="form-card">
          <h3>🔍 智慧前案快篩</h3>
          <div class="search-bar">
            <input v-model="searchKeyword" placeholder="輸入關鍵字 (如: 自動貓砂盆, Dyson吹風機)..." @keyup.enter="handleSearch">
            <button @click="handleSearch" :disabled="wizardLoading">{{ wizardLoading ? '搜尋中...' : '搜尋' }}</button>
          </div>

          <div v-if="searchResults.length > 0" class="search-results">
            <div 
              v-for="item in searchResults" 
              :key="item.patent_number" 
              class="result-item" 
              :class="{ selected: item.selected }"
              @click="toggleSearchResult(item)"
            >
              <div class="check-icon">{{ item.selected ? '✅' : '⬜' }}</div>
              <div class="info">
                <h4>{{ item.title }}</h4>
                <span class="meta">{{ item.patent_number }}</span>
                <p class="abstract">{{ item.abstract?.substring(0, 60) }}...</p>
              </div>
            </div>
          </div>

          <div class="selection-bar" v-if="selectedPatents.length > 0">
            <span>已勾選 {{ selectedPatents.length }} 篇目標</span>
            <button @click="wizardStep = 3" class="btn-next-sm">下一步 →</button>
          </div>
        </div>
        <button @click="wizardStep = 1" class="btn-text mt-2">← 返回模式選擇</button>
      </div>

      <div v-if="wizardStep === 3" class="step-content">
        <div class="form-card">
          <h3>💡 您的技術與限制</h3>
          
          <div class="form-group">
            <label>已鎖定目標 ({{ selectedPatents.length }} 篇)</label>
            <div class="tags">
              <span v-for="p in selectedPatents" :key="p.number" class="tag">{{ p.number }}</span>
            </div>
          </div>

          <div class="form-group">
            <label>技術方案描述 (My Solution) *</label>
            <textarea v-model="myIdea" rows="6" placeholder="請詳細描述您的技術實施方式，AI 將以此進行全要件比對..."></textarea>
          </div>

          <div class="form-group">
            <label>限制條件 (Constraints)</label>
            <p class="hint-text">例如：成本不能增加、必須使用塑膠材質、不能更換藍牙晶片...</p>
            <textarea v-model="constraints" rows="3" placeholder="請輸入限制條件..."></textarea>
          </div>

          <div class="wizard-actions">
            <button @click="wizardStep = 2" class="btn-text">上一步</button>
            <button @click="executeAnalysis" class="btn-primary" :disabled="wizardLoading">
              {{ wizardLoading ? '啟動分析中...' : `🚀 啟動矩陣分析 (${COST} 點)` }}
            </button>
          </div>
        </div>
      </div>
    </div>

    <div v-if="currentView === 'report'" class="report-container">
      <div class="page-header">
        <button @click="currentView = 'dashboard'" class="btn-back">← 返回儀表板</button>
        <div class="title-group">
          <h1>📊 矩陣分析報告</h1>
          <span class="status-tag" :class="jobStatus">{{ jobStatus }}</span>
        </div>
      </div>

      <div v-if="jobStatus !== 'completed'" class="processing-state">
        <div class="spinner-large"></div>
        <h2>AI 正在進行矩陣比對...</h2>
        <p>正在拆解 {{ selectedPatents.length }} 篇專利的權利範圍 (Claims)，並尋找交集漏洞。</p>
      </div>

      <div v-else-if="resultData" class="result-content">
        
        <div class="risk-summary" :class="getRiskClass(resultData.infringement_risk_assessment?.risk_level)">
          <h3>⚖️ 綜合風險等級：{{ resultData.infringement_risk_assessment?.risk_level }}</h3>
          <p>{{ resultData.infringement_risk_assessment?.reason }}</p>
        </div>

        <div class="analysis-section" v-if="resultData.matrix_analysis">
          <h4>🧩 專利矩陣分析 (Patent Matrix)</h4>
          <p class="analysis-text">{{ resultData.matrix_analysis }}</p>
        </div>

        <h3 class="section-title">💡 建議迴避策略</h3>
        <div class="strategies-grid">
          <div v-for="(strategy, idx) in resultData.strategies" :key="idx" class="strategy-card">
            <div class="card-head">
              <span class="type-tag">{{ strategy.type }}</span>
              <span class="rate-tag">成功率: {{ strategy.success_rate }}</span>
            </div>
            <h4>{{ strategy.title }}</h4>
            <p>{{ strategy.description }}</p>
            <div class="pros-cons">
              <div class="pros">✅ {{ strategy.pros }}</div>
              <div class="cons">⚠️ {{ strategy.cons }}</div>
            </div>
            <button class="btn-adopt" @click="adoptStrategy(strategy)">採用此方案撰寫專利</button>
          </div>
        </div>

        <div class="download-area">
          <button @click="downloadReport" class="btn-download" :disabled="isGenerating">
            {{ isGenerating ? '生成中...' : '📥 下載完整分析報告 (Docx)' }}
          </button>
        </div>
      </div>
    </div>

  </div>
</template>

<style scoped>
/* 共用結構 */
.workflow-container { max-width: 1200px; margin: 0 auto; padding: 2rem; color: #2c3e50; }
.header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 2rem; }
.header h1 { font-size: 1.8rem; margin: 0 0 5px 0; }
.subtitle { color: #64748b; margin: 0; }

/* Dashboard Cards */
.dashboard-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; }
.stat-card { background: white; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; cursor: pointer; text-align: center; transition: all 0.2s; }
.stat-card:hover { transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
.stat-card.active { border-color: #3b82f6; background: #eff6ff; }
.stat-value { font-size: 2rem; font-weight: bold; display: block; margin-bottom: 5px; }
.stat-label { color: #64748b; font-size: 0.9rem; }

/* Job List */
.job-list { display: grid; gap: 15px; }
.job-card { background: white; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; cursor: pointer; transition: all 0.2s; }
.job-card:hover { transform: translateY(-2px); border-color: #3b82f6; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
.card-header { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 0.85rem; color: #64748b; }
.status-badge { padding: 2px 8px; border-radius: 4px; font-size: 0.8rem; }
.status-success { background: #dcfce7; color: #166534; }
.status-processing { background: #fff7ed; color: #c2410c; }
.status-error { background: #fee2e2; color: #dc2626; }
.target-badge { background: #e0e7ff; color: #4338ca; padding: 2px 6px; border-radius: 4px; font-size: 0.8rem; margin-right: 10px; }
.risk-text { font-weight: bold; color: #dc2626; }

/* Wizard Styles */
.stepper { display: flex; justify-content: space-between; margin-bottom: 40px; }
.step { font-weight: bold; color: #ccc; }
.step.active { color: #3b82f6; }
.line { flex: 1; height: 2px; background: #eee; margin: 10px; }

.mode-cards { display: flex; gap: 20px; margin-top: 30px; justify-content: center; }
.choice-card { border: 2px solid #e2e8f0; padding: 40px; border-radius: 16px; cursor: pointer; width: 300px; transition: all 0.2s; text-align: center; background: white; }
.choice-card:hover { border-color: #3b82f6; background: #eff6ff; transform: translateY(-5px); }
.choice-card .icon { font-size: 3rem; margin-bottom: 15px; }

.form-card { background: white; padding: 30px; border-radius: 16px; border: 1px solid #e2e8f0; max-width: 800px; margin: 0 auto; }
.form-group { margin-bottom: 20px; }
.form-group label { display: block; margin-bottom: 8px; font-weight: bold; }
.hint-text { font-size: 0.9rem; color: #64748b; margin-bottom: 8px; }
textarea { width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 1rem; }

.file-drop-zone { border: 2px dashed #cbd5e1; padding: 40px; text-align: center; border-radius: 12px; color: #64748b; position: relative; }
.file-drop-zone input { position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0; cursor: pointer; }

/* Search Results in Wizard */
.search-bar { display: flex; gap: 10px; margin-bottom: 20px; }
.search-bar input { flex: 1; padding: 10px; border: 1px solid #cbd5e1; border-radius: 8px; }
.search-bar button { background: #3b82f6; color: white; border: none; padding: 0 20px; border-radius: 8px; cursor: pointer; }

.search-results { display: grid; gap: 10px; max-height: 400px; overflow-y: auto; margin-bottom: 20px; }
.result-item { border: 1px solid #e2e8f0; padding: 15px; border-radius: 8px; cursor: pointer; display: flex; gap: 15px; transition: all 0.2s; }
.result-item:hover { border-color: #cbd5e1; background: #f8fafc; }
.result-item.selected { border-color: #3b82f6; background: #eff6ff; }
.check-icon { font-size: 1.2rem; }
.meta { font-size: 0.8rem; color: #64748b; background: #e2e8f0; padding: 2px 6px; border-radius: 4px; }
.abstract { font-size: 0.9rem; color: #475569; margin: 8px 0 0 0; }

.selection-bar { display: flex; justify-content: space-between; align-items: center; background: #1e293b; color: white; padding: 15px 25px; border-radius: 8px; margin-top: 20px; }
.btn-next-sm { background: #3b82f6; color: white; border: none; padding: 6px 16px; border-radius: 4px; cursor: pointer; }

.wizard-actions { display: flex; justify-content: flex-end; gap: 15px; margin-top: 30px; }
.btn-primary, .btn-next { background: #3b82f6; color: white; border: none; padding: 10px 30px; border-radius: 8px; cursor: pointer; font-size: 1rem; }
.btn-text, .btn-back { background: transparent; border: 1px solid #cbd5e1; padding: 10px 20px; border-radius: 8px; cursor: pointer; }

/* Report Styles */
.risk-summary { padding: 25px; border-radius: 12px; margin-bottom: 30px; border-left: 6px solid #ccc; background: white; }
.risk-high { background: #fef2f2; border-color: #ef4444; color: #991b1b; }
.risk-medium { background: #fff7ed; border-color: #f59e0b; color: #92400e; }
.risk-low { background: #f0fdf4; border-color: #22c55e; color: #166534; }

.strategies-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 25px; }
.strategy-card { background: white; padding: 25px; border-radius: 16px; border: 1px solid #e2e8f0; }
.type-tag { background: #e0e7ff; color: #4338ca; padding: 4px 10px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; }
.btn-adopt { width: 100%; background: #3b82f6; color: white; border: none; padding: 12px; border-radius: 8px; cursor: pointer; margin-top: 15px; }

.download-area { text-align: center; margin-top: 40px; }
.btn-download { background: white; border: 2px solid #cbd5e1; color: #475569; padding: 12px 30px; border-radius: 30px; font-weight: bold; cursor: pointer; }

.loading, .processing-state { text-align: center; padding: 80px 0; color: #64748b; }
.spinner { border: 3px solid #f3f3f3; border-top: 3px solid #3b82f6; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 0 auto 10px; }
.spinner-large { width: 60px; height: 60px; border-width: 5px; margin-bottom: 20px; border-color: #e2e8f0; border-top-color: #3b82f6; }

.tips-area { margin-top: 50px; }

@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
</style>