<template>
  <div class="register-page">
    <h1>註冊功能開發中</h1>
    <router-link to="/auth/login">返回登入</router-link>
  </div>
</template>

<style scoped>
.register-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
}
</style>
